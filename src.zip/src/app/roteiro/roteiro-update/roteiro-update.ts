import { Component } from '@angular/core';
import { RoteiroService } from '../roteiro-service/service';
import { RoteiroInterface } from '../roteiro-models/roteiro-models';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';

@Component({
  imports: [FormsModule, ReactiveFormsModule, ReactiveFormsModule],
  selector: 'app-roteiro-update',
  styleUrl: './roteiro-update.scss',
  templateUrl: './roteiro-update.html',
})
export class RoteiroUpdate {
  alterarRoteiro!: RoteiroInterface;
  //const alterar = roteiroInterface = RoteiroInterface;
  constructor(
    private route: ActivatedRoute,
    private _roteiroSerevice: RoteiroService
  ) { }

    ngOnInit(): void {
    // Captura o ID da URL de forma segura e reativa
    this.route.paramMap.subscribe(params => {
      const id = params.get('id');
      if (id) {
        console.log('ID capturado da URL:', id);
        this.alterar(+id); // O sinal de '+' converte a string da URL para number
      }
    });
  }

  alterar = (id: number) => {
    this._roteiroSerevice.getRoteiroById(id).subscribe({
      next: (result) => {
        console.log('ID =>', id);
        this.carregaForm(result);
        //this.alterarRoteiro = result;
        console.log('Cliente encontrado:', result);
      },
      error: (err) => {
        console.error('Erro ao alterar o roteiro:', err);
      }
    });
  }

  roteiroForm = new FormGroup({
    id: new FormControl(0,{nonNullable:true}),
    cliente: new FormControl('', { validators: [Validators.required], nonNullable: true }),
    cidade: new FormControl('', { validators: [Validators.required], nonNullable: true }),
    bairro: new FormControl('', { validators: [Validators.required], nonNullable: true }),
    observacao: new FormControl('', { validators: [Validators.required], nonNullable: true }),
    cartao: new FormControl(0, { nonNullable: true }),
    lojaPolimedica: new FormControl('', { validators: [Validators.required], nonNullable: true }),
    pedidoNf: new FormControl('', { validators: [Validators.required], nonNullable: true }),
    dinheiroCheque: new FormControl(0, { nonNullable: true }),
    troco: new FormControl(0, { nonNullable: true }),
    vendedor: new FormControl('', { validators: [Validators.required], nonNullable: true }),
    responsavel: new FormControl('', { validators: [Validators.required], nonNullable: true }),
    periodo: new FormControl('', { validators: [Validators.required], nonNullable: true }),
    data: new FormControl('', { nonNullable: true }),
  });

  roteiroSubmit() {
    throw new Error('Method not implemented.');
  }

  carregaForm(result: RoteiroInterface) {
  this.roteiroForm.patchValue({
      id: result.id,
      cliente: result.cliente,
      cidade: result.cidade,
      bairro: result.bairro,
      observacao: result.observacao,
      cartao: result.cartao || 0,
      lojaPolimedica: result.lojaPolimedica,
      pedidoNf: result.pedidoNf,
      dinheiroCheque: result.dinheiroCheque || 0,
      troco: result.troco || 0,
      vendedor: result.vendedor || '',
      responsavel: result.responsavel || '',
      data: result.data || '',
      periodo: result.periodo,
    })
  }
}